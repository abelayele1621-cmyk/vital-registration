<?php
// includes/sms.php
// TextBee SMS gateway integration, plus a delivery log so the admin panel
// can see every message that was attempted and retry the ones that failed.
// Requires includes/config.php (for the API key) to already be loaded.

// Low-level: talk to the TextBee gateway directly. Does NOT write a log
// row — callers that care about a request should use sendAndLogSMS()
// below instead, so nothing is sent without a record of it.
function sendTextBeeSMS(string $recipient, string $message): array {
    $payload = json_encode([
        'recipients' => [$recipient],
        'message' => $message
    ]);

    $ch = curl_init(TEXTBEE_API_URL);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_HTTPHEADER => [
            'x-api-key: ' . TEXTBEE_API_KEY,
            'Content-Type: application/json'
        ]
    ]);

    $response = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    if ($err) {
        return ['success' => false, 'error' => $err];
    }

    $decoded = json_decode($response, true);
    if ($decoded === null) {
        return ['success' => false, 'error' => 'Invalid response from gateway', 'raw' => $response];
    }

    return $decoded;
}

// Decide whether a raw gateway response counts as delivered/queued or
// failed. TextBee's own responses vary a bit, so this treats anything
// with an explicit success flag or without an error as "sent" —
// everything else, and any curl-level error, as "failed".
function smsResultStatus(array $result): string {
    if (!empty($result['error'])) {
        return 'failed';
    }
    if (array_key_exists('success', $result)) {
        return $result['success'] ? 'sent' : 'failed';
    }
    return 'sent';
}

// High-level: send a message tied to a request and always write a row to
// sms_logs, whether it succeeds or fails, so the admin panel has a full
// delivery trail to work from.
function sendAndLogSMS(mysqli $conn, ?int $requestId, string $recipient, string $message): array {
    $result = sendTextBeeSMS($recipient, $message);
    $status = smsResultStatus($result);
    $responseText = json_encode($result);

    $stmt = $conn->prepare("
        INSERT INTO sms_logs (request_id, recipient, message, status, response, attempts, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 1, NOW(), NOW())
    ");
    $stmt->bind_param("issss", $requestId, $recipient, $message, $status, $responseText);
    $stmt->execute();
    $logId = $stmt->insert_id;
    $stmt->close();

    return ['log_id' => $logId, 'status' => $status, 'raw' => $result];
}

// Retry a previously failed (or any) log entry by id. Used by the admin
// panel's "Retry" button.
function retrySMSLog(mysqli $conn, int $logId): bool {
    $stmt = $conn->prepare("SELECT recipient, message, attempts FROM sms_logs WHERE id = ?");
    $stmt->bind_param("i", $logId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row) {
        return false;
    }

    $result = sendTextBeeSMS($row['recipient'], $row['message']);
    $status = smsResultStatus($result);
    $responseText = json_encode($result);
    $attempts = (int)$row['attempts'] + 1;

    $stmt = $conn->prepare("UPDATE sms_logs SET status = ?, response = ?, attempts = ?, updated_at = NOW() WHERE id = ?");
    $stmt->bind_param("ssii", $status, $responseText, $attempts, $logId);
    $stmt->execute();
    $stmt->close();

    return $status === 'sent';
}
?>
