<?php
// Generates (and caches to disk) a simple Ethiopian flag graphic — three
// horizontal bands (green/yellow/red) with a blue disc and a stylized
// gold star-burst emblem at the center, matching the flag's general
// look for use on the certificate header. Not pixel-perfect government
// artwork, just a recognizable rendering — same approach as
// getOfficialSealImage() in seal.php, drawn with GD since there's no
// internet access here to fetch an official asset.
function getEthiopiaFlagImage(): ?string {
    $cachePath = __DIR__ . '/../assets/images/ethiopia_flag_generated.png';

    if (file_exists($cachePath)) {
        return $cachePath;
    }

    if (!function_exists('imagecreatetruecolor')) {
        return null; // GD not installed — header just skips the flag.
    }

    $w = 300;
    $h = 200;
    $img = imagecreatetruecolor($w, $h);

    $green = imagecolorallocate($img, 8, 137, 48);
    $yellow = imagecolorallocate($img, 252, 221, 9);
    $red = imagecolorallocate($img, 218, 18, 26);
    $blue = imagecolorallocate($img, 5, 96, 199);
    $gold = imagecolorallocate($img, 250, 200, 40);

    $bandH = $h / 3;
    imagefilledrectangle($img, 0, 0, $w, $bandH, $green);
    imagefilledrectangle($img, 0, $bandH, $w, $bandH * 2, $yellow);
    imagefilledrectangle($img, 0, $bandH * 2, $w, $h, $red);

    // Central blue disc
    $cx = $w / 2;
    $cy = $h / 2;
    $radius = $h * 0.38;
    imagefilledellipse($img, (int)$cx, (int)$cy, (int)($radius * 2), (int)($radius * 2), $blue);

    // A simple gold star-burst (points radiating from center) standing in
    // for the national emblem, rather than attempting the precise crest.
    $points = [];
    $spikes = 5;
    $outerR = $radius * 0.62;
    $innerR = $radius * 0.24;
    for ($i = 0; $i < $spikes * 2; $i++) {
        $angle = M_PI * $i / $spikes - M_PI / 2;
        $rad = ($i % 2 === 0) ? $outerR : $innerR;
        $points[] = $cx + cos($angle) * $rad;
        $points[] = $cy + sin($angle) * $rad;
    }
    imagefilledpolygon($img, $points, $spikes * 2, $gold);

    imagepng($img, $cachePath);
    imagedestroy($img);

    return $cachePath;
}
