<?php
// includes/public_auth.php
// One-time-code login for the public citizen dashboard (public_login.php /
// public_verify.php / public_dashboard.php). Separate from the admin
// session system in includes/require_login.php — uses its own session key
// so a citizen and an admin can even be logged in on the same browser
// without clashing.

function normalizeIdentifier(string $raw): array {
    $raw = trim($raw);
    if (filter_var($raw, FILTER_VALIDATE_EMAIL)) {
        return ['channel' => 'email', 'value' => strtolower($raw)];
    }
    return ['channel' => 'phone', 'value' => normalizeEthiopianPhone($raw)];
}

// Converts common ways Ethiopian mobile numbers get typed into the E.164
// international format SMS gateways expect (+2519XXXXXXXX). Without this,
// gateways like TextBee will happily accept a local-format number
// ("0906098115") and report success, but the message never actually
// reaches the phone network.
function normalizeEthiopianPhone(string $raw): string {
    $digits = preg_replace('/[^0-9+]/', '', trim($raw));

    // Already international (+251...) — leave as-is.
    if (str_starts_with($digits, '+251')) {
        return $digits;
    }
    // "251906098115" (country code, no +) — add the +.
    if (str_starts_with($digits, '251') && strlen($digits) === 12) {
        return '+' . $digits;
    }
    // "0906098115" (local format, leading 0 + 9 digits) — swap 0 for +251.
    if (str_starts_with($digits, '0') && strlen($digits) === 10) {
        return '+251' . substr($digits, 1);
    }
    // "906098115" (bare 9-digit subscriber number, no leading 0) — add +251.
    if (strlen($digits) === 9 && $digits[0] !== '0') {
        return '+251' . $digits;
    }

    // Anything else (already has a different country code, or an
    // unrecognized length) — pass through unchanged rather than guess.
    return $digits;
}

// Creates a fresh 6-digit code, stores its hash, and sends it via SMS or
// email depending on the channel. Returns ['ok' => bool, 'error' => ?string].
function requestOtp(mysqli $conn, string $identifier, string $channel): array {
    // Cooldown: don't let someone spam resends.
    $stmt = $conn->prepare("SELECT created_at FROM otp_codes WHERE identifier = ? ORDER BY id DESC LIMIT 1");
    $stmt->bind_param("s", $identifier);
    $stmt->execute();
    $last = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($last) {
        $secondsSince = time() - strtotime($last['created_at']);
        if ($secondsSince < OTP_RESEND_COOLDOWN_SECONDS) {
            return ['ok' => false, 'error' => 'Please wait a moment before requesting another code.'];
        }
    }

    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $codeHash = password_hash($code, PASSWORD_DEFAULT);
    $expiresAt = date('Y-m-d H:i:s', time() + OTP_EXPIRY_MINUTES * 60);

    $stmt = $conn->prepare("INSERT INTO otp_codes (identifier, channel, code_hash, expires_at, created_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssss", $identifier, $channel, $codeHash, $expiresAt);
    $stmt->execute();
    $stmt->close();

    $message = "Debre Birhan Civil Registration: Your login code is {$code}. It expires in " . OTP_EXPIRY_MINUTES . " minutes.";

    if ($channel === 'phone') {
        $result = sendAndLogSMS($conn, null, $identifier, $message);
        if ($result['status'] !== 'sent') {
            return ['ok' => false, 'error' => 'Could not send the code by SMS. Please try again.'];
        }
    } else {
        $sent = sendOtpEmail($identifier, $message);
        if (!$sent) {
            return ['ok' => false, 'error' => 'Could not send the code by email. Please try again.'];
        }
    }

    return ['ok' => true, 'error' => null];
}

// Best-effort plain email send via PHP's mail(). This requires a working
// mail transport (sendmail/Postfix, or an SMTP relay configured at the PHP
// level) on the server — on a bare XAMPP install this will typically NOT
// actually deliver anywhere. For real deployments, swap this out for a
// proper mail library/service (PHPMailer + SMTP, an email API, etc.).
function sendOtpEmail(string $to, string $message): bool {
    $subject = 'Your Civil Registration login code';
    $headers = 'From: ' . MAIL_FROM_NAME . ' <' . MAIL_FROM_ADDRESS . '>' . "\r\n" .
               'Content-Type: text/plain; charset=UTF-8';
    return @mail($to, $subject, $message, $headers);
}

// Verifies a submitted code against the most recent unused OTP for this
// identifier. Returns true/false; also enforces a max-attempts lockout per
// code so it can't be brute-forced.
function verifyOtp(mysqli $conn, string $identifier, string $code): bool {
    $stmt = $conn->prepare("
        SELECT id, code_hash, expires_at, used, attempts
        FROM otp_codes
        WHERE identifier = ?
        ORDER BY id DESC LIMIT 1
    ");
    $stmt->bind_param("s", $identifier);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row || $row['used'] || $row['attempts'] >= 5 || strtotime($row['expires_at']) < time()) {
        return false;
    }

    $ok = password_verify($code, $row['code_hash']);

    if ($ok) {
        $stmt = $conn->prepare("UPDATE otp_codes SET used = 1 WHERE id = ?");
        $stmt->bind_param("i", $row['id']);
        $stmt->execute();
        $stmt->close();
    } else {
        $stmt = $conn->prepare("UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?");
        $stmt->bind_param("i", $row['id']);
        $stmt->execute();
        $stmt->close();
    }

    return $ok;
}

function citizenLogin(string $identifier, string $channel): void {
    $_SESSION['citizen_identifier'] = $identifier;
    $_SESSION['citizen_channel'] = $channel;
}

function citizenLoggedIn(): bool {
    return !empty($_SESSION['citizen_identifier']);
}

function requireCitizenLogin(): void {
    if (!citizenLoggedIn()) {
        header('Location: public_login.php');
        exit;
    }
}
?>
