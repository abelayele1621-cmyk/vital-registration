<?php
// Use Ethiopia's timezone consistently for issued dates, login lockouts, etc.
date_default_timezone_set('Africa/Addis_Ababa');

// Chapa payment gateway settings
define('CHAPA_SECRET_KEY', 'YOUR_CHAPA_TEST_SECRET_KEY_HERE');

// Certificate fee in ETB
define('CERTIFICATE_FEE_ETB', 500);

// TextBee SMS gateway (see includes/sms.php). Move this to an environment
// variable before going to production so the key isn't sitting in source
// control.
define('TEXTBEE_API_KEY', 'txb_X8zkp6gfyi1S9AWw0JCqUFE87HGuHBXU');
define('TEXTBEE_API_URL', 'https://api.textbee.dev/api/v1/gateway/send-sms');

// Registrar shown on the signature block of every issued certificate.
define('REGISTRAR_NAME', 'Ato Yohannes Tesfaye');
define('REGISTRAR_TITLE', 'Authorized Civil Registrar');

// How many days after issuance a certificate is considered due for
// renewal, and how many days before that expiry to start texting reminders.
define('CERTIFICATE_VALIDITY_DAYS', 365);
define('RENEWAL_REMINDER_WINDOW_DAYS', 30);

// Secret used to derive each certificate's verification code (id + issued
// date are hashed with this so codes can't be guessed or forged).
define('CERTIFICATE_VERIFICATION_SECRET', 'CHANGE_ME_TO_A_LONG_RANDOM_STRING');

// Geo-routing: sub-city/kebele -> the branch office that handles it.
// Anything not listed falls back to the Central Office.
$GLOBALS['BRANCH_MAP'] = [
    'Kebele 01' => 'Debre Birhan Zone 1 Sub-Office',
    'Kebele 02' => 'Debre Birhan Zone 1 Sub-Office',
    'Kebele 03' => 'Debre Birhan Zone 2 Sub-Office',
    'Kebele 04' => 'Debre Birhan Zone 2 Sub-Office',
    'Kebele 05' => 'Debre Birhan Zone 3 Sub-Office',
    'Kebele 06' => 'Debre Birhan Zone 3 Sub-Office',
    'Chacha'    => 'Chacha Sub-City Office',
    'Wof Washa' => 'Wof Washa Sub-City Office',
];
define('DEFAULT_BRANCH_OFFICE', 'Debre Birhan Central Office');

// Fee discount / exemption engine: categories a citizen can self-declare
// that automatically waive the certificate fee. Staff can still revoke a
// bad-faith claim from the admin panel.
$GLOBALS['FEE_EXEMPT_CATEGORIES'] = [
    'social_welfare' => 'Urgent Social Welfare Case',
    'court_order'    => 'Court-Ordered Amendment',
];

// Duplicate-detection window: block a new request if a non-rejected
// request with matching ID number/phone + same person + same cert type
// was already submitted within this many days.
define('DUPLICATE_CHECK_WINDOW_DAYS', 30);

// Public citizen dashboard: OTP login settings.
define('OTP_EXPIRY_MINUTES', 10);
define('OTP_RESEND_COOLDOWN_SECONDS', 60);
define('MAIL_FROM_ADDRESS', 'no-reply@debrebirhan-civilreg.local');
define('MAIL_FROM_NAME', 'Debre Birhan Civil Registration');

// Base URL of this site (used for Chapa callback/return URLs).
// While testing locally with XAMPP, this is usually:
define('BASE_URL', 'http://localhost/php-civil-registration');

// Admin login username.
define('ADMIN_USERNAME', 'admin');

// Admin login password, stored as a hash (never plaintext).
// Hash below is for the password "abel@1619".
define('ADMIN_PASSWORD_HASH', '$2b$10$K8tpyoZI2i1oKbDoi0mYYO92eVuZZNi.ZSUHQWh/kLHI2fvV7cV2u');

// --- Appointment booking ---
// Office hours and slot length used to generate bookable time slots per
// branch office. Slots run [start, end) in HH:MM 24h, split every
// SLOT_LENGTH_MINUTES, with SLOT_CAPACITY citizens allowed per slot.
define('APPOINTMENT_OFFICE_START', '09:00');
define('APPOINTMENT_OFFICE_END', '16:00');
define('APPOINTMENT_SLOT_LENGTH_MINUTES', 30);
define('APPOINTMENT_SLOT_CAPACITY', 4);
// How many days ahead a citizen can book (skips today so staff have
// lead time, and skips Sundays).
define('APPOINTMENT_BOOKING_WINDOW_DAYS', 21);

// --- Two-way SMS webhook ---
// TextBee (or whatever gateway you're on) should be configured to POST
// inbound replies to sms_webhook.php?secret=THIS_VALUE. Change this to a
// long random string — it's the only thing standing between the public
// internet and being able to inject fake survey ratings.
define('SMS_WEBHOOK_SECRET', 'CHANGE_ME_TO_A_LONG_RANDOM_STRING');

// --- Financial reconciliation ---
// Where the daily reconciliation cron emails its report. Falls back to
// writing a copy under reports/ if mail() isn't configured (common on a
// bare XAMPP install — see includes/public_auth.php's sendOtpEmail()).
define('FINANCE_EMAIL', 'finance@debrebirhan-civilreg.local');
