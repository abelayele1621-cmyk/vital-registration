<?php
// includes/rules.php
// Small rule-engine helpers: geo-routing to a branch office, and the fee
// exemption calculation. Requires includes/config.php to already be loaded.

function resolveBranchOffice(string $subCity): string {
    $map = $GLOBALS['BRANCH_MAP'] ?? [];
    return $map[$subCity] ?? DEFAULT_BRANCH_OFFICE;
}

function isValidExemptionCategory(string $category): bool {
    return $category === '' || array_key_exists($category, $GLOBALS['FEE_EXEMPT_CATEGORIES'] ?? []);
}

function exemptionCategoryLabel(string $category): ?string {
    return ($GLOBALS['FEE_EXEMPT_CATEGORIES'] ?? [])[$category] ?? null;
}

// Returns the fee (in ETB) that should actually be charged for a given
// exemption category — 0 if it's a recognized exempt category, the normal
// fee otherwise.
function resolveFee(string $exemptionCategory): float {
    if ($exemptionCategory !== '' && isValidExemptionCategory($exemptionCategory)) {
        return 0.0;
    }
    return (float) CERTIFICATE_FEE_ETB;
}
?>
