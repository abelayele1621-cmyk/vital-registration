<?php
// Every page that includes this header already loads includes/session.php
// first — but a couple of purely-public pages (status.php, verify.php)
// historically didn't, so this admin-nav check would silently never show.
// Guaranteeing the session is started here makes the nav reliable no
// matter what the including page already did.
if (session_status() === PHP_SESSION_NONE) {
    require_once __DIR__ . '/session.php';
}
require_once __DIR__ . '/lang.php';

$isAdmin = !empty($_SESSION['admin_logged_in']);
$currentPage = basename($_SERVER['SCRIPT_NAME']);

// Nav items are defined as data so both the desktop bar and mobile menu
// render from one source, and each link can highlight itself as "active"
// without repeating the comparison logic per-anchor.
$navItemsAdmin = [
    ['admin.php', '🗂️', t('nav_requests_admin')],
    ['admin_appointments.php', '📅', t('nav_appointments_admin')],
    ['admin_sms_logs.php', '💬', t('nav_sms_logs')],
    ['admin_ratings.php', '⭐', t('nav_ratings')],
    ['admin_audit_log.php', '🧾', t('nav_audit_log')],
    ['clear_test_data.php', '🧹', t('nav_clear_test')],
];
$navItemsPublic = [
    ['request.php', '📝', t('nav_request')],
    ['status.php', '🔍', t('nav_status')],
    ['book_appointment.php', '📅', t('nav_appointment')],
    ['verify.php', '✅', t('nav_verify')],
];
?>
<header class="site-header">
  <a href="<?php echo $assetPath ?? ''; ?>index.php" class="logo-home-link" title="Go to Home">
    <img class="logo" src="<?php echo $assetPath ?? ''; ?>assets/images/debre_birhan_logo.png" alt="Debre Birhan City Mayor Office">
  </a>
  <a href="<?php echo $assetPath ?? ''; ?>index.php" class="title-block-link">
    <div class="title-block">
      <h1><?php echo htmlspecialchars(t('site_title')); ?></h1>
      <p class="subtitle"><?php echo htmlspecialchars(t('site_subtitle')); ?></p>
    </div>
  </a>
  <a href="<?php echo $assetPath ?? ''; ?>public_dashboard.php" class="header-dashboard-link">📊 <?php echo htmlspecialchars(t('nav_my_dashboard')); ?></a>
  <a href="<?php echo $assetPath ?? ''; ?>index.php" class="logo-home-link" title="Go to Home">
    <img class="logo" src="<?php echo $assetPath ?? ''; ?>assets/images/amhara_regional_logo.png" alt="Amhara National Regional State">
  </a>
  <button type="button" class="nav-toggle" aria-label="Toggle menu" aria-expanded="false" onclick="document.querySelector('.site-nav').classList.toggle('open'); this.classList.toggle('open');">
    <span></span><span></span><span></span>
  </button>
</header>
<div class="flag-strip"><span class="green"></span><span class="gold"></span><span class="red"></span></div>

<nav class="site-nav">
  <?php $navItems = $isAdmin ? $navItemsAdmin : $navItemsPublic; ?>
  <?php foreach ($navItems as [$href, $icon, $label]): ?>
    <a href="<?php echo ($assetPath ?? '') . $href; ?>" class="<?php echo $currentPage === $href ? 'active' : ''; ?>">
      <span class="nav-icon"><?php echo $icon; ?></span><?php echo htmlspecialchars($label); ?>
    </a>
  <?php endforeach; ?>
  <?php if ($isAdmin): ?>
    <span class="site-nav-sep"></span>
    <div class="notif-bell-wrap">
      <button type="button" id="notifBell" class="notif-bell-btn" title="New requests" aria-label="New request notifications">
        🔔<span id="notifBadge" class="notif-badge" hidden>0</span>
      </button>
      <div id="notifDropdown" class="notif-dropdown" hidden>
        <div class="notif-dropdown-header">New Requests</div>
        <div id="notifList" class="notif-list">
          <p class="notif-empty">No new requests yet.</p>
        </div>
      </div>
    </div>
    <a href="<?php echo $assetPath ?? ''; ?>logout.php" class="nav-logout"><span class="nav-icon">🚪</span><?php echo htmlspecialchars(t('nav_logout')); ?></a>
  <?php else: ?>
    <span class="site-nav-sep"></span>
  <?php endif; ?>

  <div class="lang-switch-wrap">
    <button type="button" id="langSwitchBtn" class="lang-switch-btn" title="<?php echo htmlspecialchars(t('lang_switch_label')); ?>">
      <?php echo SUPPORTED_LANGUAGES[currentLang()]['flag']; ?> <?php echo htmlspecialchars(SUPPORTED_LANGUAGES[currentLang()]['label']); ?> ▾
    </button>
    <div id="langSwitchDropdown" class="lang-switch-dropdown" hidden>
      <?php foreach (SUPPORTED_LANGUAGES as $code => $info): ?>
        <a href="<?php echo $assetPath ?? ''; ?>set_lang.php?lang=<?php echo urlencode($code); ?>" class="<?php echo $code === currentLang() ? 'active' : ''; ?>">
          <?php echo $info['flag']; ?> <?php echo htmlspecialchars($info['label']); ?>
        </a>
      <?php endforeach; ?>
    </div>
  </div>

  <button type="button" id="themeToggle" class="theme-toggle-btn" title="Toggle dark mode">🌙</button>
</nav>

<script>
(function () {
  document.addEventListener('DOMContentLoaded', function () {
    var btn = document.getElementById('langSwitchBtn');
    var dd = document.getElementById('langSwitchDropdown');
    if (!btn || !dd) return;
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      dd.hidden = !dd.hidden;
    });
    document.addEventListener('click', function (e) {
      if (!dd.hidden && !dd.contains(e.target) && e.target !== btn) dd.hidden = true;
    });
  });
})();
</script>

<?php if ($isAdmin): ?>
<script src="<?php echo $assetPath ?? ''; ?>assets/notif-bell.js"></script>
<?php endif; ?>
