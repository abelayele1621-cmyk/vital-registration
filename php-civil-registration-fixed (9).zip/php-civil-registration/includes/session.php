<?php
// Centralized session bootstrap. Include this instead of calling
// session_start() directly, so every page gets the same hardened
// cookie settings.
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Strict',
        // 'secure' => true, // uncomment once the site is served over HTTPS
    ]);
    session_start();
}
