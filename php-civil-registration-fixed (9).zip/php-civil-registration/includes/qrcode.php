<?php
// Lightweight QR code helper — no Composer/library dependency.
//
// Generates a QR PNG by calling the free api.qrserver.com image API and
// caches the result to disk under /qrcache, keyed by a hash of the data.
// If the request ever fails (offline dev machine, API down, etc.) this
// simply returns null and callers must skip the QR gracefully — a
// certificate must still generate successfully even with no internet.
function getQrCodeImagePath(string $data, int $size = 220): ?string {
    $cacheDir = __DIR__ . '/../qrcache/';
    if (!is_dir($cacheDir)) {
        @mkdir($cacheDir, 0755, true);
    }

    $filename = 'qr_' . md5($data . '|' . $size) . '.png';
    $path = $cacheDir . $filename;

    if (file_exists($path) && filesize($path) > 0) {
        return $path;
    }

    $url = 'https://api.qrserver.com/v1/create-qr-code/?size=' . $size . 'x' . $size
         . '&margin=0&data=' . urlencode($data);

    $imageData = null;
    try {
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 6);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            $imageData = curl_exec($ch);
            $ok = $imageData !== false && curl_getinfo($ch, CURLINFO_HTTP_CODE) === 200;
            curl_close($ch);
            if (!$ok) {
                $imageData = null;
            }
        } elseif (ini_get('allow_url_fopen')) {
            $ctx = stream_context_create(['http' => ['timeout' => 6]]);
            $imageData = @file_get_contents($url, false, $ctx);
        }
    } catch (Throwable $e) {
        $imageData = null;
    }

    if (!$imageData) {
        return null;
    }

    file_put_contents($path, $imageData);
    return $path;
}
