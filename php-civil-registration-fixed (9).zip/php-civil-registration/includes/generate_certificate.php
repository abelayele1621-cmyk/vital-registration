<?php
require_once __DIR__ . '/fpdf/fpdf.php';
require_once __DIR__ . '/seal.php';
require_once __DIR__ . '/qrcode.php';
require_once __DIR__ . '/flag.php';

// Plain FPDF 1.9 has no rotation support built in. This is the standard,
// widely-used FPDF recipe for rotated text (a transformation-matrix PDF
// operator wrapped around a normal Cell call) — used here to lay a
// translucent-looking diagonal "OFFICIAL COPY" watermark across the
// certificate body so photocopies/scans are visibly distinguishable from
// an original printout.
class WatermarkPDF extends FPDF {
    function Rotate($angle, $x = -1, $y = -1) {
        if ($x === -1) $x = $this->x;
        if ($y === -1) $y = $this->y;
        if ($this->angle !== 0) {
            $this->_out('Q');
        }
        $this->angle = $angle;
        if ($angle !== 0) {
            $angle *= M_PI / 180;
            $c = cos($angle);
            $s = sin($angle);
            $cx = $x * $this->k;
            $cy = ($this->h - $y) * $this->k;
            $this->_out(sprintf('q %.5F %.5F %.5F %.5F %.2F %.2F cm 1 0 0 1 %.2F %.2F cm', $c, $s, -$s, $c, $cx, $cy, -$cx, -$cy));
        }
    }

    function _endpage() {
        if ($this->angle !== 0) {
            $this->angle = 0;
            $this->_out('Q');
        }
        parent::_endpage();
    }

    var $angle = 0;

    // Faint, diagonal text tiled down the page — the classic "watermark"
    // look — using a light gray so it doesn't interfere with reading the
    // certificate text printed over it. Font size and repetition are
    // computed from the actual string width so long watermark text still
    // fits on the page instead of running off the edge.
    function Watermark(string $text) {
        $this->SetFont('Arial', 'B', 22);
        $this->SetTextColor(230, 230, 230);

        $textWidth = $this->GetStringWidth($text);
        $x = ($this->w - $textWidth) / 2;

        $this->Rotate(35, $this->w / 2, $this->h / 2);
        foreach ([70, 150, 230] as $y) {
            $this->Text($x, $y, $text);
        }
        $this->Rotate(0);

        $this->SetFont('Arial', '', 12);
        $this->SetTextColor(0, 0, 0);
    }

    // A labeled underlined field, matching the "Label .......... value"
    // dotted-line style used on the official government vital-event
    // certificate forms. $width is the cell's total width in mm.
    function LabeledField(string $label, string $value, float $width, float $labelWidth = 0) {
        $x = $this->GetX();
        $y = $this->GetY();

        $this->SetFont('Arial', '', 9);
        $this->SetTextColor(60, 60, 60);
        if ($labelWidth <= 0) {
            $labelWidth = $this->GetStringWidth($label) + 2;
        }
        $this->Cell($labelWidth, 6, $label, 0, 0);

        $lineX1 = $this->GetX();
        $lineY = $y + 5.5;
        $lineX2 = $x + $width;

        $this->SetFont('Arial', 'B', 10);
        $this->SetTextColor(15, 20, 30);
        $this->Cell($width - $labelWidth, 6, $value !== '' ? $value : '', 0, 0);

        // Dotted underline under the value portion, evoking the printed
        // "........." blank line on the official paper form.
        $this->SetDrawColor(160, 160, 160);
        $this->SetLineWidth(0.2);
        $dash = 1.2;
        $gap = 0.9;
        $cx = $lineX1;
        while ($cx < $lineX2) {
            $segEnd = min($cx + $dash, $lineX2);
            $this->Line($cx, $lineY, $segEnd, $lineY);
            $cx += $dash + $gap;
        }

        $this->SetXY($x + $width, $y);
    }
}

// Per-certificate-type color theme (border/accent color), matching the
// color-coded official paper forms — pink for Adoption, warm brown for
// Death, and blue/gold for Birth & Marriage in keeping with the site's
// existing government branding.
function certTheme(string $type): array {
    $themes = [
        'birth'    => ['name' => 'Birth',    'rgb' => [26, 77, 154],  'title_en' => 'Birth Certificate'],
        'death'    => ['name' => 'Death',    'rgb' => [122, 79, 36],  'title_en' => 'Death Certificate'],
        'marriage' => ['name' => 'Marriage', 'rgb' => [180, 130, 20], 'title_en' => 'Marriage Certificate'],
        'adoption' => ['name' => 'Adoption', 'rgb' => [194, 24, 91],  'title_en' => 'Adoption Certificate (Gudifecha)'],
    ];
    return $themes[$type] ?? $themes['birth'];
}

// Renders the certificate PDF for an approved request, stamps it with the
// official seal + registrar signature block, and records a verification
// code + expiry date on the request row so verify.php and the renewal
// reminder cron can use them later.
//
// Layout note: this mirrors the field structure of the official Ethiopian
// Federal vital-event registration certificates (dual registration ID
// numbers top corners, flag, Name / Father's Name / Grandfather's Name
// convention, Mother's/Father's full name + nationality, type-specific
// detail row, and a registrar name/signature/seal footer). Ge'ez-script
// Amharic captions from the original paper forms are not reproduced here
// — this server has no Ethiopic/Ge'ez Unicode font installed to render
// them, so headings are English-only. Everything else about the layout
// (field order, dual ID numbers, color-coded border per type, flag
// placement) matches the official forms.
//
// $conn is optional so existing callers that don't have a connection handy
// still work — but pass it whenever possible so the verification code
// gets persisted.
function generateCertificate($request, ?mysqli $conn = null) {
    $issuedAt = date('Y-m-d H:i:s');
    $verificationCode = generateVerificationCode((int)$request['id'], $issuedAt);
    $expiryDate = date('Y-m-d', strtotime($issuedAt . ' + ' . CERTIFICATE_VALIDITY_DAYS . ' days'));

    if ($conn) {
        $stmt = $conn->prepare("UPDATE requests SET verification_code = ?, issued_at = ?, expiry_date = ? WHERE id = ?");
        $stmt->bind_param("sssi", $verificationCode, $issuedAt, $expiryDate, $request['id']);
        $stmt->execute();
        $stmt->close();
    }

    $type = $request['certificate_type'];
    $theme = certTheme($type);
    [$r, $g, $b] = $theme['rgb'];

    $pdf = new WatermarkPDF();
    $pdf->AddPage();
    $pdf->Watermark('OFFICIAL COPY - DEBRE BIRHAN VITAL EVENTS REGISTRATION');

    // ===== Color-coded frame border (matches the official paper form's
    // colored-border look, color-coded per certificate type) =====
    $margin = 6;
    $pdf->SetDrawColor($r, $g, $b);
    $pdf->SetLineWidth(1.8);
    $pdf->Rect($margin, $margin, 210 - 2 * $margin, 297 - 2 * $margin);
    $pdf->SetLineWidth(0.4);
    $pdf->Rect($margin + 2.5, $margin + 2.5, 210 - 2 * ($margin + 2.5), 297 - 2 * ($margin + 2.5));
    $pdf->SetLineWidth(0.2);

    $innerLeft = $margin + 8;
    $innerRight = 210 - $margin - 8;
    $innerWidth = $innerRight - $innerLeft;

    // ===== Header: dual registration ID numbers (top corners) + flag =====
    $pdf->SetFont('Arial', 'B', 7.5);
    $pdf->SetTextColor(60, 60, 60);

    $leftIdLabel = $type === 'adoption' ? 'Adoption Register Form Number' : 'Register Form Number';
    $leftIdValue = $type === 'adoption' ? ($request['adoption_reg_form_number'] ?? '') : ('REQ-' . $request['id']);
    $pdf->SetXY($innerLeft, $margin + 6);
    $pdf->Cell($innerWidth / 2 - 5, 4, $leftIdLabel, 0, 1);
    $pdf->SetX($innerLeft);
    $pdf->SetFont('Arial', '', 8);
    $pdf->Cell($innerWidth / 2 - 5, 4, $leftIdValue !== '' ? $leftIdValue : '-', 0, 1);

    $rightIdLabel = $type === 'adoption' ? 'Adoption Registration Unique ID Number' : 'Registration Unique ID Number';
    $rightIdValue = $verificationCode;
    $pdf->SetXY($innerLeft + $innerWidth / 2 + 5, $margin + 6);
    $pdf->SetFont('Arial', 'B', 7.5);
    $pdf->Cell($innerWidth / 2 - 5, 4, $rightIdLabel, 0, 1, 'R');
    $pdf->SetXY($innerLeft + $innerWidth / 2 + 5, $margin + 10);
    $pdf->SetFont('Arial', '', 8);
    $pdf->Cell($innerWidth / 2 - 5, 4, $rightIdValue, 0, 1, 'R');

    if ($type === 'adoption' && !empty($request['birth_reg_unique_id'])) {
        $pdf->SetXY($innerLeft + $innerWidth / 2 + 5, $margin + 16);
        $pdf->SetFont('Arial', 'B', 7.5);
        $pdf->Cell($innerWidth / 2 - 5, 4, 'Birth Registration Unique ID Number', 0, 1, 'R');
        $pdf->SetXY($innerLeft + $innerWidth / 2 + 5, $margin + 20);
        $pdf->SetFont('Arial', '', 8);
        $pdf->Cell($innerWidth / 2 - 5, 4, $request['birth_reg_unique_id'], 0, 1, 'R');
    }

    // Ethiopian flag, centered
    $flagPath = getEthiopiaFlagImage();
    if ($flagPath && file_exists($flagPath)) {
        $pdf->Image($flagPath, (210 - 26) / 2, $margin + 8, 26, 17);
    }
    $pdf->SetY($margin + 28);

    // ===== Government header =====
    $pdf->SetTextColor(20, 20, 20);
    $pdf->SetFont('Arial', 'B', 13);
    $pdf->Cell(0, 7, 'Federal Democratic Republic of Ethiopia', 0, 1, 'C');
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(0, 6, 'Vital Event Registration', 0, 1, 'C');
    $pdf->Ln(1);

    $pdf->SetTextColor($r, $g, $b);
    $pdf->SetFont('Arial', 'B', 15);
    $pdf->Cell(0, 9, strtoupper($theme['title_en']), 0, 1, 'C');
    $pdf->SetTextColor(60, 60, 60);
    $pdf->SetFont('Arial', '', 9);
    $pdf->Cell(0, 5, 'Debre Birhan City Civil Registration and Residency Service - Amhara National Regional State', 0, 1, 'C');
    $pdf->Ln(4);

    // Thin rule under the header
    $pdf->SetDrawColor($r, $g, $b);
    $pdf->Line($innerLeft, $pdf->GetY(), $innerRight, $pdf->GetY());
    $pdf->Ln(5);

    $pdf->SetTextColor(0, 0, 0);
    $colWidth = $innerWidth / 3;

    // ===== Name / Father's Name / Grandfather's Name (the standard
    // three-part Ethiopian given-name convention) =====
    $pdf->SetX($innerLeft);
    $pdf->LabeledField('Name: ', $request['person_full_name'] ?? '', $colWidth);
    $pdf->LabeledField("Father's Name: ", $request['father_name'] ?? '', $colWidth);
    $pdf->LabeledField("Grandfather's Name: ", $request['person_grandfather_name'] ?? '', $colWidth);
    $pdf->Ln(9);

    // ===== Sex / Date of Birth (birth, marriage, adoption - not shown
    // for death, which has its own date-of-death row below) =====
    if ($type !== 'death') {
        $dobParts = ['', '', ''];
        if (!empty($request['person_dob'])) {
            $ts = strtotime($request['person_dob']);
            $dobParts = [date('F', $ts), date('j', $ts), date('Y', $ts)];
        }
        $pdf->SetX($innerLeft);
        $pdf->LabeledField('Sex: ', $request['person_sex'] ? ucfirst($request['person_sex']) : '', $colWidth);
        $pdf->LabeledField('Date of Birth - Month: ', $dobParts[0], $colWidth * 0.7);
        $pdf->LabeledField('Date: ', (string)$dobParts[1], $colWidth * 0.5);
        $pdf->LabeledField('Year: ', (string)$dobParts[2], $colWidth * 0.8);
        $pdf->Ln(9);
    }

    // ===== Place/Country of Birth / Region / Zone =====
    $pdf->SetX($innerLeft);
    $pdf->LabeledField('Place/Country of Birth: ', $request['person_place_of_birth'] ?? '', $colWidth);
    $pdf->LabeledField('Region/City Administration: ', 'Amhara / Debre Birhan', $colWidth);
    $pdf->LabeledField('Zone/City Administration: ', $request['sub_city'] ?? '', $colWidth);
    $pdf->Ln(9);

    // ===== Mother's Full Name / Nationality =====
    $pdf->SetX($innerLeft);
    $pdf->LabeledField("Mother's Full Name: ", $request['mother_name'] ?? '', $innerWidth * 0.65);
    $pdf->LabeledField("Mother's Nationality: ", $request['mother_nationality'] ?? 'Ethiopian', $innerWidth * 0.35);
    $pdf->Ln(9);

    // ===== Father's Full Name / Nationality =====
    $pdf->SetX($innerLeft);
    $pdf->LabeledField("Father's Full Name: ", $request['father_name'] ?? '', $innerWidth * 0.65);
    $pdf->LabeledField("Father's Nationality: ", $request['father_nationality'] ?? 'Ethiopian', $innerWidth * 0.35);
    $pdf->Ln(11);

    // ===== Type-specific detail row =====
    $pdf->SetFillColor(245, 246, 249);
    $pdf->Rect($innerLeft, $pdf->GetY() - 2, $innerWidth, 22, 'F');

    if ($type === 'death') {
        $dodParts = ['', '', ''];
        if (!empty($request['date_of_death'])) {
            $ts = strtotime($request['date_of_death']);
            $dodParts = [date('F', $ts), date('j', $ts), date('Y', $ts)];
        }
        $pdf->SetX($innerLeft);
        $pdf->LabeledField('Title: ', $request['deceased_title'] ?? '', $colWidth * 0.7);
        $pdf->LabeledField('Sex: ', $request['person_sex'] ? ucfirst($request['person_sex']) : '', $colWidth * 0.6);
        $pdf->LabeledField('Place of Death: ', $request['place_of_death'] ?? '', $colWidth * 1.7);
        $pdf->Ln(8);
        $pdf->SetX($innerLeft);
        $pdf->LabeledField('Date of Death - Month: ', $dodParts[0], $colWidth * 0.8);
        $pdf->LabeledField('Date: ', (string)$dodParts[1], $colWidth * 0.5);
        $pdf->LabeledField('Year: ', (string)$dodParts[2], $colWidth * 0.7);
        $pdf->Ln(9);
    } elseif ($type === 'marriage') {
        $mdParts = ['', '', ''];
        if (!empty($request['marriage_date'])) {
            $ts = strtotime($request['marriage_date']);
            $mdParts = [date('F', $ts), date('j', $ts), date('Y', $ts)];
        }
        $pdf->SetX($innerLeft);
        $pdf->LabeledField("Spouse's Full Name: ", $request['spouse_name'] ?? '', $innerWidth);
        $pdf->Ln(8);
        $pdf->SetX($innerLeft);
        $pdf->LabeledField('Date of Marriage - Month: ', $mdParts[0], $colWidth * 0.85);
        $pdf->LabeledField('Date: ', (string)$mdParts[1], $colWidth * 0.5);
        $pdf->LabeledField('Year: ', (string)$mdParts[2], $colWidth * 0.65);
        $pdf->Ln(8);
        $pdf->SetX($innerLeft);
        $pdf->LabeledField('Place of Marriage: ', $request['marriage_place'] ?? '', $innerWidth);
        $pdf->Ln(9);
    } elseif ($type === 'adoption') {
        $createdTs = strtotime($request['created_at'] ?? 'now');
        $pdf->SetX($innerLeft);
        $pdf->LabeledField('Date of Adoption Registration - Month: ', date('F', $createdTs), $colWidth * 1.1);
        $pdf->LabeledField('Date: ', date('j', $createdTs), $colWidth * 0.45);
        $pdf->LabeledField('Year: ', date('Y', $createdTs), $colWidth * 0.45);
        $pdf->Ln(8);
        $pdf->SetX($innerLeft);
        $pdf->LabeledField('Certificate Issued Date - Month: ', date('F'), $colWidth * 1.1);
        $pdf->LabeledField('Date: ', date('j'), $colWidth * 0.45);
        $pdf->LabeledField('Year: ', date('Y'), $colWidth * 0.45);
        $pdf->Ln(9);
    } else {
        // Birth certificate: purpose the certificate was requested for.
        $pdf->SetX($innerLeft);
        $pdf->LabeledField('Purpose: ', $request['purpose'] ?: 'General', $innerWidth);
        $pdf->Ln(9);
    }

    $pdf->Ln(3);

    // ===== Registrar / Signature / Seal footer =====
    $pdf->SetX($innerLeft);
    $pdf->LabeledField('Name of Civil Registrar: ', REGISTRAR_NAME, $innerWidth);
    $pdf->Ln(11);

    $sigY = $pdf->GetY();
    $pdf->SetDrawColor(80, 80, 80);
    $pdf->Line($innerLeft, $sigY + 16, $innerLeft + 70, $sigY + 16);
    $pdf->SetXY($innerLeft, $sigY + 17);
    $pdf->SetFont('Arial', '', 8);
    $pdf->SetTextColor(80, 80, 80);
    $pdf->Cell(70, 4, 'Signature - ' . REGISTRAR_TITLE, 0, 1);
    $pdf->SetX($innerLeft);
    $pdf->Cell(70, 4, 'Signed electronically on ' . date('Y-m-d'), 0, 1);

    $sealPath = getOfficialSealImage();
    if ($sealPath && file_exists($sealPath)) {
        $pdf->Image($sealPath, $innerRight - 42, $sigY - 6, 42, 42);
    }
    $pdf->SetXY($innerRight - 42, $sigY + 34);
    $pdf->SetFont('Arial', 'I', 7.5);
    $pdf->Cell(42, 4, 'Seal', 0, 1, 'C');

    $pdf->SetY($sigY + 44);

    // Verification code, so anyone holding the printed page can confirm
    // it's genuine via verify.php without needing to contact the office.
    $pdf->SetFont('Courier', 'B', 10);
    $pdf->SetTextColor($r, $g, $b);
    $pdf->Cell(0, 6, 'Verification Code: ' . $verificationCode, 0, 1, 'C');
    $pdf->SetFont('Arial', '', 8);
    $pdf->SetTextColor(90, 90, 90);
    $pdf->Cell(0, 5, 'Verify this certificate at ' . (defined('BASE_URL') ? BASE_URL : '') . '/verify.php using the Certificate ID and this code.', 0, 1, 'C');
    $pdf->Ln(3);

    // Scan-to-verify QR code: encodes a direct link straight to verify.php
    // with the ID + code pre-filled, so a phone camera can confirm the
    // certificate instantly with no typing. Degrades silently -- if the QR
    // image can't be fetched (e.g. no internet on this machine), the
    // certificate still finishes generating with the text code above as
    // the fallback verification method.
    $verifyUrl = (defined('BASE_URL') ? BASE_URL : '') . '/verify.php?id=' . $request['id'] . '&code=' . urlencode($verificationCode);
    $qrPath = getQrCodeImagePath($verifyUrl, 220);
    if ($qrPath) {
        $qrSize = 20; // mm
        $qrX = (210 - $qrSize) / 2;
        $qrY = $pdf->GetY();
        $pdf->Image($qrPath, $qrX, $qrY, $qrSize, $qrSize);
        $pdf->SetXY(0, $qrY + $qrSize + 1);
        $pdf->SetFont('Arial', '', 7);
        $pdf->SetTextColor(120, 120, 120);
        $pdf->Cell(0, 4, 'Scan to verify instantly', 0, 1, 'C');
        $pdf->Ln(2);
    }

    $pdf->SetFont('Arial', 'I', 8);
    $pdf->SetTextColor(90, 90, 90);
    $pdf->SetX($innerLeft);
    $pdf->MultiCell($innerWidth, 4.5, 'This is an official document issued by the Debre Birhan City Civil Registration and Residency Service, Amhara National Regional State. It bears a digital seal and registrar signature and is valid without further stamping. Certificate ID: ' . $request['id'] . ' - Issued: ' . date('Y-m-d') . ' - Valid Until: ' . $expiryDate, 0, 'C');

    $outputPath = __DIR__ . '/../certificates/certificate_' . $request['id'] . '.pdf';
    $pdf->Output('F', $outputPath);

    return [
        'verification_code' => $verificationCode,
        'issued_at' => $issuedAt,
        'expiry_date' => $expiryDate,
    ];
}
?>
