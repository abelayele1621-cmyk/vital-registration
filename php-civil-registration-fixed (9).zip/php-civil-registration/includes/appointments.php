<?php
// includes/appointments.php
// Slot generation + booking helpers for the appointment system. Requires
// includes/config.php to already be loaded for the APPOINTMENT_* constants.

// Every bookable calendar date between tomorrow and the booking window,
// skipping Sundays (the office is closed).
function getBookableDates(): array {
    $dates = [];
    $cursor = new DateTime('tomorrow');
    $end = (new DateTime('today'))->modify('+' . APPOINTMENT_BOOKING_WINDOW_DAYS . ' days');
    while ($cursor <= $end) {
        if ((int)$cursor->format('w') !== 0) { // 0 = Sunday
            $dates[] = $cursor->format('Y-m-d');
        }
        $cursor->modify('+1 day');
    }
    return $dates;
}

// All time slots for a single day, e.g. ["09:00", "09:30", ... ].
function getDaySlotTimes(): array {
    $slots = [];
    $cursor = DateTime::createFromFormat('H:i', APPOINTMENT_OFFICE_START);
    $end = DateTime::createFromFormat('H:i', APPOINTMENT_OFFICE_END);
    while ($cursor < $end) {
        $slots[] = $cursor->format('H:i');
        $cursor->modify('+' . APPOINTMENT_SLOT_LENGTH_MINUTES . ' minutes');
    }
    return $slots;
}

// Slot times for a given branch/date that still have room, with how many
// spots remain in each (so the UI can show "3 spots left" etc).
function getAvailableSlots(mysqli $conn, string $branchOffice, string $date): array {
    $stmt = $conn->prepare("
        SELECT appointment_time, COUNT(*) AS booked
        FROM appointments
        WHERE branch_office = ? AND appointment_date = ? AND status = 'booked'
        GROUP BY appointment_time
    ");
    $stmt->bind_param("ss", $branchOffice, $date);
    $stmt->execute();
    $result = $stmt->get_result();
    $bookedCounts = [];
    while ($row = $result->fetch_assoc()) {
        // MySQL TIME comes back as HH:MM:SS; normalize to HH:MM to match getDaySlotTimes().
        $bookedCounts[substr($row['appointment_time'], 0, 5)] = (int)$row['booked'];
    }
    $stmt->close();

    $available = [];
    foreach (getDaySlotTimes() as $time) {
        $remaining = APPOINTMENT_SLOT_CAPACITY - ($bookedCounts[$time] ?? 0);
        if ($remaining > 0) {
            $available[] = ['time' => $time, 'remaining' => $remaining];
        }
    }
    return $available;
}

// Attempts to book a slot. Re-checks capacity right before inserting
// (best-effort race protection — two citizens could still both pass the
// check a split second apart, but the window is tiny and the cost of a
// slightly-overbooked slot is low for this use case).
function bookAppointment(mysqli $conn, int $requestId, string $branchOffice, string $date, string $time, string $purpose): array {
    $stmt = $conn->prepare("
        SELECT COUNT(*) AS c FROM appointments
        WHERE branch_office = ? AND appointment_date = ? AND appointment_time = ? AND status = 'booked'
    ");
    $stmt->bind_param("sss", $branchOffice, $date, $time);
    $stmt->execute();
    $count = (int)$stmt->get_result()->fetch_assoc()['c'];
    $stmt->close();

    if ($count >= APPOINTMENT_SLOT_CAPACITY) {
        return ['ok' => false, 'error' => 'That time slot just filled up. Please pick another.'];
    }

    // One active appointment per request at a time — cancel any existing
    // booking for this request before creating the new one.
    $cancelStmt = $conn->prepare("UPDATE appointments SET status = 'cancelled' WHERE request_id = ? AND status = 'booked'");
    $cancelStmt->bind_param("i", $requestId);
    $cancelStmt->execute();
    $cancelStmt->close();

    $insertStmt = $conn->prepare("
        INSERT INTO appointments (request_id, branch_office, appointment_date, appointment_time, purpose, status)
        VALUES (?, ?, ?, ?, ?, 'booked')
    ");
    $insertStmt->bind_param("issss", $requestId, $branchOffice, $date, $time, $purpose);
    $ok = $insertStmt->execute();
    $insertStmt->close();

    return $ok ? ['ok' => true, 'error' => null] : ['ok' => false, 'error' => 'Could not save the appointment. Please try again.'];
}

function getAppointmentForRequest(mysqli $conn, int $requestId): ?array {
    $stmt = $conn->prepare("
        SELECT * FROM appointments WHERE request_id = ? AND status = 'booked' ORDER BY id DESC LIMIT 1
    ");
    $stmt->bind_param("i", $requestId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}
?>
