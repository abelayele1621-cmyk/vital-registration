<?php
// Include this at the very top of any page that should require admin login.
require_once __DIR__ . '/session.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/csrf.php';
