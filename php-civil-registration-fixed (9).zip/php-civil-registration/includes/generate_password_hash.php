<?php
// One-time helper: generates a password hash to paste into includes/config.php
// as ADMIN_PASSWORD_HASH. Delete this file once you're done using it —
// it should not stay reachable on a live server.
//
// Command line:
//   php includes/generate_password_hash.php "your-new-password"
//
// Or visit in a browser (local/dev only):
//   http://localhost/php-civil-registration/includes/generate_password_hash.php?password=your-new-password

$password = $argv[1] ?? ($_GET['password'] ?? null);

if (!$password) {
    $usage = "Usage: php generate_password_hash.php \"your-new-password\"\n"
           . "Or visit this file in your browser with ?password=your-new-password\n";
    if (php_sapi_name() === 'cli') {
        echo $usage;
    } else {
        header('Content-Type: text/plain');
        echo $usage;
    }
    exit;
}

$hash = password_hash($password, PASSWORD_DEFAULT);

if (php_sapi_name() === 'cli') {
    echo $hash . "\n";
} else {
    header('Content-Type: text/plain');
    echo "Paste this into includes/config.php as ADMIN_PASSWORD_HASH:\n\n" . $hash . "\n\n";
    echo "Then delete this file (generate_password_hash.php) — do not leave it on a live server.\n";
}
