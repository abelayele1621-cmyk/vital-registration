<?php $fp = $assetPath ?? ''; require_once __DIR__ . '/lang.php'; ?>
<footer class="rich-footer">
  <div class="rich-footer-inner">

    <div class="footer-col footer-brand">
      <div class="footer-logo-row">
        <span class="footer-badge">🏛️</span>
        <div>
          <span class="footer-brand-name">Debre Birhan</span><br>
          <span class="footer-brand-sub">CIVIL REGISTRATION</span>
        </div>
      </div>
      <p><?php echo htmlspecialchars(t('footer_tagline')); ?></p>
    </div>

    <div class="footer-col">
      <h4><?php echo htmlspecialchars(t('footer_quick_links')); ?></h4>
      <a href="<?php echo $fp; ?>index.php">🏠 <?php echo htmlspecialchars(t('footer_home')); ?></a>
      <a href="<?php echo $fp; ?>request.php">📝 <?php echo htmlspecialchars(t('footer_submit')); ?></a>
      <a href="<?php echo $fp; ?>status.php">🔍 <?php echo htmlspecialchars(t('footer_check_status')); ?></a>
      <a href="<?php echo $fp; ?>book_appointment.php">📅 <?php echo htmlspecialchars(t('footer_book_appt')); ?></a>
      <a href="<?php echo $fp; ?>verify.php">✅ <?php echo htmlspecialchars(t('footer_verify')); ?></a>
    </div>

    <div class="footer-col">
      <h4><?php echo htmlspecialchars(t('footer_account')); ?></h4>
      <a href="<?php echo $fp; ?>public_login.php">📊 <?php echo htmlspecialchars(t('footer_my_dashboard')); ?></a>
      <a href="<?php echo $fp; ?>login.php">🔑 <?php echo htmlspecialchars(t('footer_staff_login')); ?></a>
    </div>

    <div class="footer-col footer-tip">
      <h4>⚠️ <?php echo htmlspecialchars(t('footer_good_to_know')); ?></h4>
      <p><?php echo htmlspecialchars(t('footer_tip')); ?></p>
    </div>

  </div>

  <div class="footer-bottom">
    &copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars(t('footer_bottom')); ?>
  </div>
</footer>
