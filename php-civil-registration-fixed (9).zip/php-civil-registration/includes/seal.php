<?php
// includes/seal.php
// Generates the circular "official seal" graphic overlaid on every
// certificate, plus the verification code that lets anyone confirm a
// certificate is genuine on verify.php.

// Renders (and caches to disk) a semi-transparent circular seal so we
// don't regenerate the same artwork on every certificate. Returns the
// absolute path to the PNG, or null if the GD extension isn't available.
function getOfficialSealImage(): ?string {
    $cachePath = __DIR__ . '/../assets/images/official_seal_generated.png';

    if (file_exists($cachePath)) {
        return $cachePath;
    }

    if (!function_exists('imagecreatetruecolor')) {
        return null; // GD not installed — certificate still generates, just without the seal graphic.
    }

    $size = 400;
    $img = imagecreatetruecolor($size, $size);
    imagesavealpha($img, true);
    $transparent = imagecolorallocatealpha($img, 0, 0, 0, 127);
    imagefill($img, 0, 0, $transparent);

    $gold = imagecolorallocatealpha($img, 180, 138, 20, 25);
    $center = $size / 2;

    // Concentric rings
    imagesetthickness($img, 6);
    imageellipse($img, $center, $center, $size - 20, $size - 20, $gold);
    imagesetthickness($img, 2);
    imageellipse($img, $center, $center, $size - 46, $size - 46, $gold);

    // Curved text around the top of the seal ("DEBRE BIRHAN CITY ADMIN.")
    $topText = 'DEBRE BIRHAN CITY ADMINISTRATION * ';
    $radius = ($size - 60) / 2;
    $chars = str_split($topText);
    $totalAngle = 200; // degrees of arc used
    $startAngle = 250; // degrees, going clockwise from center-right = 0
    $step = $totalAngle / max(1, count($chars) - 1);

    $fontFile = null;
    foreach ([
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
        '/usr/share/fonts/truetype/freefont/FreeSansBold.ttf',
    ] as $candidate) {
        if (file_exists($candidate)) { $fontFile = $candidate; break; }
    }

    if ($fontFile) {
        foreach ($chars as $i => $ch) {
            $angleDeg = $startAngle + $i * $step;
            $angleRad = deg2rad($angleDeg);
            $x = $center + $radius * cos($angleRad);
            $y = $center + $radius * sin($angleRad);
            // Rotate each letter to stay tangent to the circle.
            $rotation = -($angleDeg - 90);
            imagettftext($img, 11, $rotation, (int)$x, (int)$y, $gold, $fontFile, $ch);
        }
    }

    // Central emblem: a simple 5-point star + "OFFICIAL SEAL"
    $points = [];
    $outerR = 34; $innerR = 14;
    for ($i = 0; $i < 10; $i++) {
        $r = ($i % 2 === 0) ? $outerR : $innerR;
        $angle = deg2rad(-90 + $i * 36);
        $points[] = $center + $r * cos($angle);
        $points[] = $center + $r * sin($angle) - 30;
    }
    imagefilledpolygon($img, $points, 10, $gold);

    if ($fontFile) {
        $label = 'OFFICIAL SEAL';
        $bbox = imagettfbbox(13, 0, $fontFile, $label);
        $textWidth = $bbox[2] - $bbox[0];
        imagettftext($img, 13, 0, (int)($center - $textWidth / 2), (int)($center + 55), $gold, $fontFile, $label);

        $label2 = 'AMHARA REGION';
        $bbox2 = imagettfbbox(10, 0, $fontFile, $label2);
        $textWidth2 = $bbox2[2] - $bbox2[0];
        imagettftext($img, 10, 0, (int)($center - $textWidth2 / 2), (int)($center + 75), $gold, $fontFile, $label2);
    }

    imagepng($img, $cachePath);
    imagedestroy($img);

    return $cachePath;
}

// Deterministic-but-unguessable verification code for a certificate.
// Anyone can check id + this code on verify.php; without the site secret
// they can't forge one for a different id.
function generateVerificationCode(int $requestId, string $issuedAt): string {
    $raw = hash('sha256', $requestId . '|' . $issuedAt . '|' . CERTIFICATE_VERIFICATION_SECRET);
    return strtoupper(substr($raw, 0, 12));
}
?>
