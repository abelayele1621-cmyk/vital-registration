<?php
// Database connection settings (XAMPP defaults)
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "civil_registration";

// Connect to MySQL server (without selecting a database yet)
$conn = new mysqli($db_host, $db_user, $db_pass);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create the database if it doesn't exist
$conn->query("CREATE DATABASE IF NOT EXISTS $db_name");
$conn->select_db($db_name);

// Create the requests table if it doesn't exist
$sql = "
CREATE TABLE IF NOT EXISTS requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    certificate_type VARCHAR(20) NOT NULL,
    applicant_name VARCHAR(255) NOT NULL,
    applicant_relationship VARCHAR(100) NOT NULL,
    applicant_id_number VARCHAR(100) NOT NULL,
    applicant_phone VARCHAR(50) NOT NULL,
    applicant_email VARCHAR(255),
    applicant_address VARCHAR(255),
    person_full_name VARCHAR(255) NOT NULL,
    person_dob DATE NULL,
    person_place_of_birth VARCHAR(255),
    person_sex VARCHAR(10),
    father_name VARCHAR(255),
    mother_name VARCHAR(255),
    purpose VARCHAR(255),
    num_copies INT DEFAULT 1,
    delivery_method VARCHAR(20),
    payment_status VARCHAR(20) DEFAULT 'unpaid',
    request_status VARCHAR(20) DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)";

if (!$conn->query($sql)) {
    die("Error creating table: " . $conn->error);
}

// Migration: add tx_ref column for sites created before this was tracked
// (MySQL 8 / MariaDB 10.0.2+ both support IF NOT EXISTS here).
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS tx_ref VARCHAR(100) NULL");

// Migration: supporting ID document uploaded during the request wizard.
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS applicant_id_document VARCHAR(255) NULL");

// Migration: whether the initial \"request received\" SMS was confirmed
// sent by the gateway — feeds the citizen-facing activity timeline.
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS sms_verified TINYINT(1) NOT NULL DEFAULT 0");

// Migration: digital signature / official seal support. A verification
// code is generated once the certificate is issued so anyone can confirm
// authenticity on verify.php without exposing internal record IDs alone.
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS verification_code VARCHAR(64) NULL");
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS issued_at DATETIME NULL");

// Migration: certificate expiry + renewal reminders.
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS expiry_date DATE NULL");
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS renewal_reminder_sent TINYINT(1) NOT NULL DEFAULT 0");

// Migration: geo-routing to the correct sub-city/kebele branch office.
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS sub_city VARCHAR(100) NULL");
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS branch_office VARCHAR(150) NULL");

// Migration: fee discount / exemption engine.
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS exemption_category VARCHAR(50) NULL");
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS fee_charged DECIMAL(10,2) NULL");

// Migration: fields needed to match the official Ethiopian vital-event
// certificate formats (bilingual government layout) — grandfather's name
// is the third part of the standard Ethiopian given-name convention
// (Name / Father's Name / Grandfather's Name), used across all
// certificate types. The rest are type-specific: title/place-of-death/
// date-of-death for death certificates, and spouse/marriage details for
// marriage certificates. Also adds 'adoption' (Gudifecha) support.
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS person_grandfather_name VARCHAR(255) NULL");
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS mother_nationality VARCHAR(100) NULL");
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS father_nationality VARCHAR(100) NULL");
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS deceased_title VARCHAR(50) NULL");
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS place_of_death VARCHAR(255) NULL");
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS date_of_death DATE NULL");
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS spouse_name VARCHAR(255) NULL");
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS marriage_date DATE NULL");
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS marriage_place VARCHAR(255) NULL");
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS adoption_reg_form_number VARCHAR(100) NULL");
$conn->query("ALTER TABLE requests ADD COLUMN IF NOT EXISTS birth_reg_unique_id VARCHAR(100) NULL");

// Tracks failed admin login attempts per IP, for lockout.
$conn->query("
CREATE TABLE IF NOT EXISTS login_attempts (
    ip_address VARCHAR(45) PRIMARY KEY,
    attempts INT DEFAULT 0,
    locked_until DATETIME NULL,
    last_attempt DATETIME NULL
)");

// SMS Notification Queue & Delivery Logs — every message TextBee was
// asked to send, whether it succeeded, and how many times we've retried.
$conn->query("
CREATE TABLE IF NOT EXISTS sms_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    request_id INT NULL,
    recipient VARCHAR(50) NOT NULL,
    message TEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    response TEXT NULL,
    attempts INT NOT NULL DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX (request_id),
    INDEX (status)
)");

// Custom document notes / revision requests attached to a request by staff.
$conn->query("
CREATE TABLE IF NOT EXISTS request_notes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    request_id INT NOT NULL,
    note TEXT NOT NULL,
    requires_revision TINYINT(1) NOT NULL DEFAULT 0,
    created_by VARCHAR(100) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX (request_id)
)");

// Migration: citizen self-service correction requests reuse this same
// table (created_by = 'citizen') rather than a separate one, so staff see
// a single chronological note thread per request. `source` distinguishes
// who wrote it and `status` tracks whether a citizen's correction request
// still needs action.
$conn->query("ALTER TABLE request_notes ADD COLUMN IF NOT EXISTS source VARCHAR(20) NOT NULL DEFAULT 'staff'");
$conn->query("ALTER TABLE request_notes ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'open'");

// Audit log — who did what to which request, and when. Covers approve/
// reject, mark-paid, and staff note/revision-request actions.
$conn->query("
CREATE TABLE IF NOT EXISTS audit_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    request_id INT NULL,
    admin_username VARCHAR(100) NOT NULL,
    action VARCHAR(50) NOT NULL,
    details VARCHAR(255) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX (request_id)
)");

// Daily financial reconciliation run log, so admins can see past runs
// instead of only reading the emailed report.
$conn->query("
CREATE TABLE IF NOT EXISTS reconciliation_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_date DATE NOT NULL,
    requests_paid INT NOT NULL DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    mismatches INT NOT NULL DEFAULT 0,
    mismatch_detail TEXT NULL,
    emailed TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY (report_date)
)");

// One-time codes for the public citizen dashboard login (phone or email).
$conn->query("
CREATE TABLE IF NOT EXISTS otp_codes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    identifier VARCHAR(150) NOT NULL,
    channel VARCHAR(10) NOT NULL,
    code_hash VARCHAR(255) NOT NULL,
    expires_at DATETIME NOT NULL,
    used TINYINT(1) NOT NULL DEFAULT 0,
    attempts INT NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX (identifier)
)");

// Appointment booking: a citizen picks a date/time slot at the branch
// office handling their request (for pickup, biometric capture, or a
// sworn affidavit). Capacity is enforced per branch/date/time so the
// office doesn't get overbooked.
$conn->query("
CREATE TABLE IF NOT EXISTS appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    request_id INT NOT NULL,
    branch_office VARCHAR(150) NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    purpose VARCHAR(30) NOT NULL DEFAULT 'pickup',
    status VARCHAR(20) NOT NULL DEFAULT 'booked',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX (request_id),
    INDEX (branch_office, appointment_date, appointment_time)
)");

// Post-issuance satisfaction ratings (1-5), collected by asking the
// citizen to reply to the \"certificate approved\" SMS with a number.
$conn->query("
CREATE TABLE IF NOT EXISTS satisfaction_ratings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    request_id INT NOT NULL,
    phone VARCHAR(50) NOT NULL,
    rating TINYINT NULL,
    feedback_text VARCHAR(255) NULL,
    requested_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    responded_at DATETIME NULL,
    INDEX (request_id)
)");
?>
