// Live "new request" notification bell for the admin nav. Polls
// admin_notifications.php every 20s; badge count and dropdown list update
// without a page reload. The "last seen" timestamp is kept in
// localStorage so the badge count survives across page navigations
// within the admin area, and clears once the admin actually opens the
// dropdown (treated as "seen").
(function () {
  const STORAGE_KEY = 'civilreg-notif-last-seen';
  const POLL_MS = 20000;

  document.addEventListener('DOMContentLoaded', function () {
    const bell = document.getElementById('notifBell');
    const badge = document.getElementById('notifBadge');
    const dropdown = document.getElementById('notifDropdown');
    const list = document.getElementById('notifList');
    if (!bell || !badge || !dropdown || !list) return;

    function getLastSeen() {
      return localStorage.getItem(STORAGE_KEY) || '';
    }
    function setLastSeen(ts) {
      localStorage.setItem(STORAGE_KEY, ts);
    }

    function renderList(items) {
      if (!items.length) {
        list.innerHTML = '<p class="notif-empty">No new requests yet.</p>';
        return;
      }
      list.innerHTML = items.map(function (item) {
        const typeLabel = item.certificate_type.charAt(0).toUpperCase() + item.certificate_type.slice(1);
        return '<a class="notif-item" href="admin.php?q=' + encodeURIComponent(item.id) + '">' +
          '<span class="notif-item-icon">📝</span>' +
          '<span class="notif-item-body">' +
            '<strong>#' + item.id + '</strong> — ' + typeLabel + ' request<br>' +
            '<span class="notif-item-name">' + item.applicant_name.replace(/</g, '&lt;') + '</span>' +
          '</span>' +
        '</a>';
      }).join('');
    }

    function poll() {
      const since = getLastSeen() || new Date(Date.now() - 3600000).toISOString().slice(0, 19).replace('T', ' ');
      fetch('admin_notifications.php?since=' + encodeURIComponent(since))
        .then(function (res) { return res.json(); })
        .then(function (data) {
          renderList(data.items || []);
          const count = data.count || 0;
          if (count > 0) {
            badge.textContent = count > 9 ? '9+' : String(count);
            badge.hidden = false;
            bell.classList.add('has-new');
          } else {
            badge.hidden = true;
            bell.classList.remove('has-new');
          }
          // Only advance "last seen" once the dropdown has actually been
          // opened — see toggleDropdown() below — so the badge persists
          // until the admin notices it, not just until the next poll.
        })
        .catch(function () { /* silent — notifications are best-effort */ });
    }

    function toggleDropdown() {
      const opening = dropdown.hidden;
      dropdown.hidden = !opening;
      if (opening) {
        // Mark everything currently shown as seen.
        setLastSeen(new Date().toISOString().slice(0, 19).replace('T', ' '));
        badge.hidden = true;
        bell.classList.remove('has-new');
      }
    }

    bell.addEventListener('click', function (e) {
      e.stopPropagation();
      toggleDropdown();
    });
    document.addEventListener('click', function (e) {
      if (!dropdown.hidden && !dropdown.contains(e.target) && e.target !== bell) {
        dropdown.hidden = true;
      }
    });

    // Seed "last seen" to now on a brand new session so the very first
    // poll doesn't surface the last hour of history as "new".
    if (!getLastSeen()) {
      setLastSeen(new Date().toISOString().slice(0, 19).replace('T', ' '));
    }

    poll();
    setInterval(poll, POLL_MS);
  });
})();
