// Dark mode toggle. Preference is stored in localStorage so it persists
// across pages and visits. Applied as early as possible (this script is
// loaded in <head>, before the body renders) to avoid a "flash" of the
// wrong theme on page load.
(function () {
  const STORAGE_KEY = 'civilreg-theme';

  function getPreferredTheme() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === 'dark' || saved === 'light') return saved;
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
  }

  // Apply immediately (script runs in <head> before <body> paints).
  applyTheme(getPreferredTheme());

  // Wire up the toggle button once the DOM is ready.
  document.addEventListener('DOMContentLoaded', function () {
    const btn = document.getElementById('themeToggle');
    if (!btn) return;

    function updateIcon() {
      const current = document.documentElement.getAttribute('data-theme');
      btn.textContent = current === 'dark' ? '☀️' : '🌙';
      btn.setAttribute('aria-label', current === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
    }
    updateIcon();

    btn.addEventListener('click', function () {
      const current = document.documentElement.getAttribute('data-theme');
      const next = current === 'dark' ? 'light' : 'dark';
      applyTheme(next);
      localStorage.setItem(STORAGE_KEY, next);
      updateIcon();
    });
  });
})();
